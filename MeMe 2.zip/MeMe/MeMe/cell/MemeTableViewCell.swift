//
//  MemeTableViewCell.swift
//  MeMe
//
//  Created by شيما on 27/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class MemeTableViewCell: UITableViewCell {

   
    //Outlet , Make sure it's connected with storyboard
    
    @IBOutlet weak var memeLabel: UILabel!
    
    @IBOutlet weak var memeImageView: UIImageView!
    
}
