//
//  ViewController.swift
//  MeMe
//
//  Created by شيما on 07/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import Foundation

//MARK: add protocols

class ViewController: UIViewController , UIImagePickerControllerDelegate,UINavigationControllerDelegate ,UITextFieldDelegate {

    
    
    
    //MARK:Outlet , Make sure it's connected with storyboard
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var photoButton: UIBarButtonItem!

    @IBOutlet weak var cameraButton: UIBarButtonItem!
    
    @IBOutlet weak var textFiled1: UITextField!
    
    @IBOutlet weak var textFiled2: UITextField!
    
    @IBOutlet weak var share: UIBarButtonItem!
    
    @IBOutlet weak var toolBar: UIToolbar!
    
    
    
    
    //reading “TOP” and “BOTTOM” when a user opens the Meme Editor.
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textStyle(textField: textFiled1, defaultText: "TOP")
        textStyle(textField: textFiled2, defaultText: "BOTTOM")
        
    }
    
    /* declare constant memeTextAttributes that contain the attributes(Text should approximate the "Impact" font, all caps, white with a black outline), then using defaultTextAttributes take the attributes
     & textAlignment (Text should be center-aligned) */
    
    
    func textStyle(textField: UITextField, defaultText: String) {
   
        
        let memeTextAttributes:[NSAttributedString.Key: Any] = [
    NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeColor.rawValue) : UIColor.black,
    NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue) : UIColor.white,
    NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue) : UIFont(name: "HelveticaNeue-CondensedBlack", size: 32)!,
    NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeWidth.rawValue) : -3.0
        ]

        textField.defaultTextAttributes = memeTextAttributes
        textField.delegate = self
        textField.textAlignment = .center
        textField.text = defaultText
    }
    
    
    
    //MATR: Disabling the Camera Button .
    //MARK: Enable & Disable share Button .

    override func viewWillAppear(_ animated: Bool) {
      super.viewWillAppear(animated)
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)
        if imageView.image == nil {
            share.isEnabled = false
        } else {
            share.isEnabled = true
        }
        
        //MARK: call func
            subscribeToNotificationsObserver()
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboarNotifications()

    
    }

    //MARK: camera
 //call openImage func (picker constant , present & , declaring source type here).
    @IBAction func camera(_ sender: Any) {
    openImage(.camera)
    }
    
    //MARK: share
    // UIActivityViewController use to show the launch activity , then ... present it .

    @IBAction func share(_ sender: Any) {
        let memeImage = generateMemedImage()
        let activity = UIActivityViewController(activityItems: [memeImage], applicationActivities: nil)
        activity.completionWithItemsHandler = { (_, completed, _, _) in
            if(completed) {
                self.save(memeImage)
                self.dismiss(animated: true, completion: nil)
            }
        }
        present(activity, animated: true)
        
    }
    
    
    //MARK: To save image
    // create the memem object & save it on the meme array
    
    private func save(_ memedImage: UIImage) {
        //update meme
        
        let meme = Meme(topText: textFiled1.text!, bottomText: textFiled2.text!, originalImage: imageView.image!, memedImage: memedImage)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.memes.append(meme)
    }
    
    
    //MARK: present image picker to Camera Roll
    //call openImage func (picker constant , present & , declaring source type here).
    @IBAction func pickImage(_ sender: Any) {
        openImage(.photoLibrary)
       
        
    }
    
    //MARK: create func ,take picker constant to open an image from studio
    /*set the delegate before launching the imagePicker . then using source type you without declaring it,
    then specify whether an image is coming from the album or from the camera*/
    
    func openImage(_ type: UIImagePickerController.SourceType){
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = type
        present(picker, animated: true, completion: nil)     }
    
    
    
    //MARK: to get access to an image chosen from the Photo library or camera.
    
    
    //using didFinishPickingMediaWithInfo to Tells the delegate that the user picked a still image or movie.
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imageView.image = image
            picker.dismiss(animated: true, completion: nil )
            
        }
        
    }
    
    //using imagePickerControllerDidCancel to Tells the delegate that the user cancelled the pick operation.

func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
    picker.dismiss(animated: true, completion: nil)
}
    
    /*Adds an entry to the notification center's dispatch table with an observer, a selector, and an optional notification name and sender.*/
    

    private func subscribeToNotificationsObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
   
    
    //MARK: keyboard
    @objc private func keyboardWillShow(_ notification: Notification) {
        if textFiled2.isFirstResponder {
            view.frame.origin.y -= getKeyboardHeight(notification)}
  
        }
    //to move the view back down when the keyboard is dismissed
    @objc private func keyboardWillHide(_ notification: Notification) {
        view.frame.origin.y = 0
    }

    //Removes matching entries from the receiver’s dispatch table.
    
    func unsubscribeFromKeyboarNotifications(){
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    //MARK: using textFieldDidBeginEditing (When a user taps inside a textfield, the default text should clear)
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textFiled1.text == "TOP" || textFiled2.text == "BOTTOM" {
            textField.text = ""
        }
        
    }
    
    
    //MARK: using textFieldShouldReturn (When a user presses return, the keyboard should be dismissed).
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
   
    func getKeyboardHeight(_ notification: Notification) -> CGFloat{
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
    
    
    //MARK: cancel Button
    @IBAction func cancel(_ sender: Any){

        textFiled1.text = "TOP"
    
        textFiled2.text = "BOTTOM"
    
        imageView.image = nil
    
        share.isEnabled = false
        
    }
    
    
    /*using generateMemedImage (Combining image and text )render the view hierarchy(image & textfields in this case) into a UIImage object.*/
    
    private func generateMemedImage() -> UIImage {
        /*call textFieldDidBeginEditing func to  delete text if the user does not write in TOP & BOTTOM when the image saved.*/
    textFieldDidBeginEditing(textFiled1)
     textFieldDidBeginEditing(textFiled2)
        
        // Hide toolbar and navbar
        hideTopBottomBars(true)
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
       // Show toolbar and navbar
        hideTopBottomBars(false)
        
        return memedImage
    }
    
    
    
    private func hideTopBottomBars(_ hide: Bool) {
        navigationController?.navigationBar.isHidden = hide
        toolBar.isHidden = hide
        view.backgroundColor = hide ? .clear : .black
    }
    
    
}
