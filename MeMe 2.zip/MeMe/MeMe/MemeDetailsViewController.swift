//
//  MemeDetailsViewController.swift
//  MeMe
//
//  Created by شيما on 27/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class MemeDetailsViewController: UIViewController {

    //defined variable imageView
    
    var imageView = UIImageView()
    
    
    
    // to make all image in thesame size
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.anchor(top: view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 0, paddingRight: 0, width: 0, height: 0)
        
  
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        view.addSubview(imageView)
        imageView.frame = view.frame
        imageView.contentMode = .scaleAspectFit
    }

   
}
