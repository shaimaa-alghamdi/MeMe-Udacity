//
//  MemeTableViewController.swift
//  MeMe
//
//  Created by شيما on 27/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
// protocol UITableViewController

class MemeTableViewController: UITableViewController {
   
    
    var memes: [Meme] {
        let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
        return appDelegate.memes
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

 
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    tableView.reloadData()
    }
    
    // MARK:Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return memes.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MemeCell", for: indexPath) as! MemeTableViewCell
        
        let meme = memes[indexPath.row]
        
        // Set the name and image
        cell.memeImageView.image = meme.memedImage
        cell.memeLabel.text = "\(meme.topText) ... \(meme.bottomText)"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.size.height / 8.0
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = MemeDetailsViewController()
        vc.imageView.image = memes[indexPath.row].memedImage
        navigationController?.pushViewController(vc, animated: true)
    }

}
